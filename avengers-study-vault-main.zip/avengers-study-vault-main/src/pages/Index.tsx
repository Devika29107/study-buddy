import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import Dashboard from '@/components/Dashboard';
import GeminiChat from '@/components/GeminiChat';
import ArcReactorTimer from '@/components/ArcReactorTimer';
import HeroBadges from '@/components/HeroBadges';
import { Shield, Bot, Timer, Trophy, Zap, Menu } from 'lucide-react';
import heroBackground from '@/assets/avengers-hud-bg.jpg';

const Index = () => {
  const [activeTab, setActiveTab] = useState('gemini');

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Header */}
      <div 
        className="relative h-64 bg-cover bg-center bg-no-repeat flex items-center justify-center"
        style={{ backgroundImage: `url(${heroBackground})` }}
      >
        <div className="absolute inset-0 bg-black/60" />
        <div className="relative z-10 text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <Shield className="h-12 w-12 text-primary arc-reactor" />
            <h1 className="text-5xl font-orbitron font-bold jarvis-text">
              AVENGERS STUDY BUDDY
            </h1>
            <Zap className="h-12 w-12 text-accent arc-reactor" />
          </div>
          <p className="text-xl text-foreground/80 font-exo">
            Assemble your knowledge. Become the hero of your studies.
          </p>
          <div className="flex items-center justify-center gap-2 text-sm text-primary">
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
            <span className="font-orbitron">JARVIS ONLINE</span>
            <div className="w-2 h-2 bg-primary rounded-full animate-pulse" />
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <div className="flex justify-center">
            <TabsList className="hologram-panel p-2">
              <TabsTrigger value="dashboard" className="flex items-center gap-2 font-orbitron">
                <Shield className="h-4 w-4" />
                HQ
              </TabsTrigger>
              <TabsTrigger value="gemini" className="flex items-center gap-2 font-orbitron">
                <Bot className="h-4 w-4" />
                GEMINI
              </TabsTrigger>
              <TabsTrigger value="timer" className="flex items-center gap-2 font-orbitron">
                <Timer className="h-4 w-4" />
                ARC REACTOR
              </TabsTrigger>
              <TabsTrigger value="badges" className="flex items-center gap-2 font-orbitron">
                <Trophy className="h-4 w-4" />
                HEROES
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <Dashboard />
          </TabsContent>

          {/* Gemini Chat Tab */}
          <TabsContent value="gemini" className="space-y-6">
            <div className="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <GeminiChat />
              </div>
              <div className="space-y-4">
                <Card className="hologram-panel">
                  <CardContent className="p-4 text-center">
                    <Bot className="h-12 w-12 mx-auto mb-2 text-primary arc-reactor" />
                    <h3 className="font-orbitron font-bold">Gemini AI Assistant</h3>
                    <p className="text-sm text-muted-foreground mt-2">
                      Powered by Google's Gemini AI, ready to help with any study questions, 
                      provide explanations, create quizzes, and offer motivation.
                    </p>
                  </CardContent>
                </Card>
                
                <Card className="hologram-panel">
                  <CardContent className="p-4">
                    <h4 className="font-medium mb-2">Quick Commands:</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-primary rounded-full" />
                        <span>"Explain quantum physics"</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-accent rounded-full" />
                        <span>"Quiz me on math"</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-secondary rounded-full" />
                        <span>"Motivate me"</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-1 h-1 bg-success rounded-full" />
                        <span>"Study plan for chemistry"</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Timer Tab */}
          <TabsContent value="timer" className="space-y-6">
            <div className="max-w-2xl mx-auto">
              <ArcReactorTimer />
            </div>
          </TabsContent>

          {/* Badges Tab */}
          <TabsContent value="badges" className="space-y-6">
            <HeroBadges />
          </TabsContent>
        </Tabs>
      </div>

      {/* Footer */}
      <footer className="text-center py-8 border-t border-border/50">
        <div className="container mx-auto px-4">
          <p className="text-sm text-muted-foreground font-exo">
            "Whatever it takes." — Avengers Study Protocol
          </p>
          <div className="flex items-center justify-center gap-2 mt-2">
            <div className="w-1 h-1 bg-primary rounded-full animate-pulse" />
            <span className="text-xs text-primary font-orbitron">SHIELD ACADEMY CERTIFIED</span>
            <div className="w-1 h-1 bg-primary rounded-full animate-pulse" />
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
