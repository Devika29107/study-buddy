import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Trophy, Zap, Shield, Brain, Target, Clock, BookOpen, Award } from 'lucide-react';

interface HeroBadge {
  id: string;
  name: string;
  description: string;
  icon: React.ComponentType<any>;
  progress: number;
  unlocked: boolean;
  rarity: 'common' | 'rare' | 'legendary';
  hero: string;
}

const HeroBadges = () => {
  const badges: HeroBadge[] = [
    {
      id: 'iron-genius',
      name: 'Iron Genius',
      description: 'Complete 100 math problems',
      icon: Brain,
      progress: 73,
      unlocked: false,
      rarity: 'legendary',
      hero: 'Iron Man'
    },
    {
      id: 'cap-discipline',
      name: 'Captain\'s Discipline',
      description: 'Study for 7 consecutive days',
      icon: Shield,
      progress: 100,
      unlocked: true,
      rarity: 'rare',
      hero: 'Captain America'
    },
    {
      id: 'hulk-endurance',
      name: 'Hulk Endurance',
      description: 'Study for 4+ hours in a day',
      icon: Zap,
      progress: 100,
      unlocked: true,
      rarity: 'rare',
      hero: 'Hulk'
    },
    {
      id: 'hawkeye-precision',
      name: 'Hawkeye Precision',
      description: 'Score 100% on 5 quizzes',
      icon: Target,
      progress: 60,
      unlocked: false,
      rarity: 'common',
      hero: 'Hawkeye'
    },
    {
      id: 'thor-power',
      name: 'Thor\'s Lightning',
      description: 'Complete physics mastery',
      icon: Zap,
      progress: 85,
      unlocked: false,
      rarity: 'legendary',
      hero: 'Thor'
    },
    {
      id: 'widow-stealth',
      name: 'Black Widow Stealth',
      description: 'Learn in silence mode for 50 hours',
      icon: Clock,
      progress: 32,
      unlocked: false,
      rarity: 'rare',
      hero: 'Black Widow'
    },
    {
      id: 'strange-mystic',
      name: 'Doctor Strange Wisdom',
      description: 'Master all 6 infinity subjects',
      icon: BookOpen,
      progress: 67,
      unlocked: false,
      rarity: 'legendary',
      hero: 'Doctor Strange'
    },
    {
      id: 'first-study',
      name: 'First Study Session',
      description: 'Complete your first study session',
      icon: Award,
      progress: 100,
      unlocked: true,
      rarity: 'common',
      hero: 'Rookie'
    }
  ];

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'bg-muted';
      case 'rare': return 'bg-primary';
      case 'legendary': return 'bg-accent';
      default: return 'bg-muted';
    }
  };

  const getRarityGlow = (rarity: string) => {
    switch (rarity) {
      case 'common': return '';
      case 'rare': return 'glow-arc';
      case 'legendary': return 'glow-gold';
      default: return '';
    }
  };

  const unlockedBadges = badges.filter(badge => badge.unlocked);
  const inProgressBadges = badges.filter(badge => !badge.unlocked && badge.progress > 0);
  const lockedBadges = badges.filter(badge => !badge.unlocked && badge.progress === 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-orbitron font-bold jarvis-text">
          HERO BADGE COLLECTION
        </h2>
        <p className="text-muted-foreground">
          Unlock legendary achievements on your path to becoming a study hero
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="hologram-panel text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-orbitron font-bold text-success">
              {unlockedBadges.length}
            </div>
            <p className="text-sm text-muted-foreground">Unlocked</p>
          </CardContent>
        </Card>
        <Card className="hologram-panel text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-orbitron font-bold text-primary">
              {inProgressBadges.length}
            </div>
            <p className="text-sm text-muted-foreground">In Progress</p>
          </CardContent>
        </Card>
        <Card className="hologram-panel text-center">
          <CardContent className="p-4">
            <div className="text-2xl font-orbitron font-bold text-muted-foreground">
              {badges.length}
            </div>
            <p className="text-sm text-muted-foreground">Total</p>
          </CardContent>
        </Card>
      </div>

      {/* Unlocked Badges */}
      {unlockedBadges.length > 0 && (
        <Card className="hologram-panel">
          <CardHeader>
            <CardTitle className="font-orbitron flex items-center gap-2">
              <Trophy className="h-5 w-5 text-accent" />
              EARNED BADGES
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {unlockedBadges.map((badge) => {
                const IconComponent = badge.icon;
                return (
                  <div key={badge.id} className="text-center space-y-2 group">
                    <div className={`w-16 h-16 mx-auto rounded-full ${getRarityColor(badge.rarity)} ${getRarityGlow(badge.rarity)} flex items-center justify-center hero-badge animate-float`}>
                      <IconComponent className="h-8 w-8 text-white" />
                    </div>
                    <div>
                      <h3 className="font-medium text-sm">{badge.name}</h3>
                      <p className="text-xs text-muted-foreground">{badge.hero}</p>
                      <Badge className={`text-xs mt-1 ${getRarityColor(badge.rarity)}`}>
                        {badge.rarity.toUpperCase()}
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* In Progress Badges */}
      {inProgressBadges.length > 0 && (
        <Card className="hologram-panel">
          <CardHeader>
            <CardTitle className="font-orbitron flex items-center gap-2">
              <Target className="h-5 w-5 text-primary" />
              IN PROGRESS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {inProgressBadges.map((badge) => {
                const IconComponent = badge.icon;
                return (
                  <div key={badge.id} className="flex items-center gap-4 p-3 rounded-lg bg-muted/30 border border-border/50">
                    <div className={`w-12 h-12 rounded-full ${getRarityColor(badge.rarity)} flex items-center justify-center opacity-70`}>
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">{badge.name}</h3>
                      <p className="text-sm text-muted-foreground">{badge.description}</p>
                      <div className="mt-2 space-y-1">
                        <Progress value={badge.progress} className="energy-bar" />
                        <p className="text-xs text-muted-foreground">{badge.progress}% complete</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {badge.hero}
                    </Badge>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Locked Badges */}
      {lockedBadges.length > 0 && (
        <Card className="hologram-panel">
          <CardHeader>
            <CardTitle className="font-orbitron flex items-center gap-2">
              <Shield className="h-5 w-5 text-muted-foreground" />
              CLASSIFIED MISSIONS
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {lockedBadges.map((badge) => {
                const IconComponent = badge.icon;
                return (
                  <div key={badge.id} className="text-center space-y-2 opacity-50">
                    <div className="w-16 h-16 mx-auto rounded-full bg-muted flex items-center justify-center">
                      <IconComponent className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <div>
                      <h3 className="font-medium text-sm">???</h3>
                      <p className="text-xs text-muted-foreground">Classified</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default HeroBadges;