import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Send, Brain, Target, Lightbulb, Zap, User, Bot } from 'lucide-react';

interface ChatMessage {
  id: number;
  text: string;
  sender: 'user' | 'gemini';
  timestamp: Date;
  type?: 'analysis' | 'quiz' | 'explanation' | 'motivation';
}

const GeminiChat = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 1,
      text: "Hello! I'm Gemini, your AI-powered study assistant. I'm here to help you learn, understand complex topics, create quizzes, and provide motivation. How can I assist you today?",
      sender: 'gemini',
      timestamp: new Date(),
      type: 'analysis'
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const quickActions = [
    { label: "Explain Simply", icon: Brain, type: "explanation" },
    { label: "Create Quiz", icon: Target, type: "quiz" },
    { label: "Study Analysis", icon: Lightbulb, type: "analysis" },
    { label: "Motivate Me", icon: Zap, type: "motivation" }
  ];

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: ChatMessage = {
      id: messages.length + 1,
      text: inputValue,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentMessage = inputValue;
    setInputValue('');
    setIsTyping(true);

    try {
      const response = await fetch(`${window.location.origin}/functions/v1/chat-with-gemini`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          message: currentMessage,
          messageType: 'analysis'
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get response');
      }

      const data = await response.json();
      
      const geminiMessage: ChatMessage = {
        id: messages.length + 2,
        text: data.response,
        sender: 'gemini',
        timestamp: new Date(),
        type: 'analysis'
      };

      setMessages(prev => [...prev, geminiMessage]);
    } catch (error) {
      console.error('Error:', error);
      const errorMessage: ChatMessage = {
        id: messages.length + 2,
        text: "I apologize, but I'm experiencing technical difficulties. Please try again.",
        sender: 'gemini',
        timestamp: new Date(),
        type: 'analysis'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleQuickAction = async (type: string) => {
    let prompt = "";
    switch (type) {
      case "explanation":
        prompt = "Explain a complex concept in the simplest way possible, using analogies and examples that anyone can understand.";
        break;
      case "quiz":
        prompt = "Create an engaging quiz question on a random educational topic that would challenge a student.";
        break;
      case "analysis":
        prompt = "Provide a detailed analysis about effective study strategies and learning techniques.";
        break;
      case "motivation":
        prompt = "Give an inspiring motivational message to help someone who might be struggling with their studies.";
        break;
    }

    setIsTyping(true);

    try {
      const response = await fetch(`${window.location.origin}/functions/v1/chat-with-gemini`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          message: prompt,
          messageType: type
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get response');
      }

      const data = await response.json();
      
      const geminiMessage: ChatMessage = {
        id: messages.length + 1,
        text: data.response,
        sender: 'gemini',
        timestamp: new Date(),
        type: type as any
      };

      setMessages(prev => [...prev, geminiMessage]);
    } catch (error) {
      console.error('Error:', error);
      const errorMessage: ChatMessage = {
        id: messages.length + 1,
        text: "I apologize, but I'm experiencing technical difficulties. Please try again.",
        sender: 'gemini',
        timestamp: new Date(),
        type: type as any
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const getMessageIcon = (type?: string) => {
    switch (type) {
      case 'analysis': return <Lightbulb className="h-4 w-4" />;
      case 'quiz': return <Target className="h-4 w-4" />;
      case 'explanation': return <Brain className="h-4 w-4" />;
      case 'motivation': return <Zap className="h-4 w-4" />;
      default: return <Sparkles className="h-4 w-4" />;
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="hologram-panel h-[600px] flex flex-col">
      <CardHeader>
        <CardTitle className="font-orbitron flex items-center gap-2 text-primary">
          <Sparkles className="h-5 w-5 arc-reactor" />
          GEMINI AI ASSISTANT
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col space-y-4">
        {/* Quick Actions */}
        <div className="flex flex-wrap gap-2">
          {quickActions.map((action) => (
            <Button
              key={action.label}
              variant="outline"
              size="sm"
              onClick={() => handleQuickAction(action.type)}
              className="hero-badge text-xs"
            >
              <action.icon className="h-3 w-3 mr-1" />
              {action.label}
            </Button>
          ))}
        </div>

        {/* Chat Messages */}
        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.sender === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted border border-border/50'
                  }`}
                >
                  {message.sender === 'gemini' && (
                    <div className="flex items-center gap-2 mb-2">
                      {getMessageIcon(message.type)}
                      <Badge variant="outline" className="text-xs">
                        {message.type?.toUpperCase() || 'GEMINI'}
                      </Badge>
                    </div>
                  )}
                  {message.sender === 'user' && (
                    <div className="flex items-center gap-2 mb-2">
                      <User className="h-4 w-4" />
                      <Badge variant="secondary" className="text-xs">
                        YOU
                      </Badge>
                    </div>
                  )}
                  <p className="text-sm whitespace-pre-wrap">{message.text}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-muted p-3 rounded-lg border border-border/50">
                  <div className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4 animate-pulse" />
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="flex gap-2">
          <Textarea
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Ask me anything about your studies..."
            onKeyDown={handleKeyPress}
            className="bg-input border-border/50 min-h-[40px] max-h-[120px] resize-none"
            rows={1}
          />
          <Button 
            onClick={handleSendMessage} 
            className="arc-reactor self-end"
            disabled={!inputValue.trim() || isTyping}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default GeminiChat;