import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Play, Pause, RotateCcw, Coffee, Zap } from 'lucide-react';

const ArcReactorTimer = () => {
  const [timeLeft, setTimeLeft] = useState(25 * 60); // 25 minutes in seconds
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'work' | 'break'>('work');
  const [cycle, setCycle] = useState(1);

  const workDuration = 25 * 60; // 25 minutes
  const shortBreakDuration = 5 * 60; // 5 minutes
  const longBreakDuration = 15 * 60; // 15 minutes

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;

    if (isActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(timeLeft => timeLeft - 1);
      }, 1000);
    } else if (timeLeft === 0) {
      // Timer completed
      if (mode === 'work') {
        if (cycle % 4 === 0) {
          // Long break after 4 cycles
          setTimeLeft(longBreakDuration);
          setMode('break');
        } else {
          // Short break
          setTimeLeft(shortBreakDuration);
          setMode('break');
        }
      } else {
        // Break finished, start new work session
        setTimeLeft(workDuration);
        setMode('work');
        setCycle(prev => prev + 1);
      }
      setIsActive(false);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isActive, timeLeft, mode, cycle]);

  const toggleTimer = () => {
    setIsActive(!isActive);
  };

  const resetTimer = () => {
    setIsActive(false);
    setTimeLeft(mode === 'work' ? workDuration : shortBreakDuration);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getProgress = () => {
    const totalTime = mode === 'work' ? workDuration : 
                     cycle % 4 === 0 ? longBreakDuration : shortBreakDuration;
    return ((totalTime - timeLeft) / totalTime) * 100;
  };

  const getModeMessage = () => {
    if (mode === 'work') {
      return "Focus Mode: Channel your inner Tony Stark";
    } else {
      return cycle % 4 === 0 ? "Long Break: Even heroes need rest" : "Short Break: Recharge your Arc Reactor";
    }
  };

  return (
    <Card className="hologram-panel">
      <CardHeader>
        <CardTitle className="font-orbitron flex items-center gap-2 jarvis-text">
          <Zap className="h-5 w-5 arc-reactor" />
          ARC REACTOR TIMER
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Timer Display */}
        <div className="text-center space-y-4">
          <div className="relative">
            <div className={`w-40 h-40 mx-auto rounded-full border-8 ${
              mode === 'work' ? 'border-primary glow-arc' : 'border-accent glow-gold'
            } flex items-center justify-center arc-reactor`}>
              <div className="text-4xl font-orbitron font-bold">
                {formatTime(timeLeft)}
              </div>
            </div>
            
            {/* Progress Ring */}
            <svg className="absolute inset-0 w-40 h-40 mx-auto -rotate-90">
              <circle
                cx="80"
                cy="80"
                r="72"
                fill="none"
                stroke="currentColor"
                strokeWidth="4"
                className="text-muted opacity-20"
              />
              <circle
                cx="80"
                cy="80"
                r="72"
                fill="none"
                stroke="currentColor"
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray={`${2 * Math.PI * 72}`}
                strokeDashoffset={`${2 * Math.PI * 72 * (1 - getProgress() / 100)}`}
                className={mode === 'work' ? 'text-primary' : 'text-accent'}
                style={{ transition: 'stroke-dashoffset 1s ease-in-out' }}
              />
            </svg>
          </div>

          <Badge 
            className={`${mode === 'work' ? 'bg-primary' : 'bg-accent'} hero-badge`}
          >
            {mode === 'work' ? (
              <>
                <Zap className="h-3 w-3 mr-1" />
                FOCUS MODE
              </>
            ) : (
              <>
                <Coffee className="h-3 w-3 mr-1" />
                BREAK TIME
              </>
            )}
          </Badge>

          <p className="text-sm text-muted-foreground">
            {getModeMessage()}
          </p>
        </div>

        {/* Controls */}
        <div className="flex justify-center gap-3">
          <Button
            onClick={toggleTimer}
            className={`${isActive ? 'bg-secondary' : 'bg-primary'} hero-badge`}
          >
            {isActive ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <Button onClick={resetTimer} variant="outline" className="hero-badge">
            <RotateCcw className="h-4 w-4" />
          </Button>
        </div>

        {/* Cycle Info */}
        <div className="text-center space-y-2">
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4].map((num) => (
              <div
                key={num}
                className={`w-3 h-3 rounded-full ${
                  num <= (cycle - 1) % 4 + 1 ? 'bg-primary' : 'bg-muted'
                }`}
              />
            ))}
          </div>
          <p className="text-xs text-muted-foreground">
            Cycle {cycle} • {cycle % 4 === 0 && mode === 'break' ? 'Long Break' : `Session ${(cycle - 1) % 4 + 1}/4`}
          </p>
        </div>

        {/* Stark Quote */}
        <div className="text-center p-4 bg-muted/30 rounded-lg border border-border/50">
          <blockquote className="text-sm italic text-primary">
            "Sometimes you gotta run before you can walk."
          </blockquote>
          <p className="text-xs text-muted-foreground mt-1">— Tony Stark</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ArcReactorTimer;