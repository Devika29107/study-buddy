import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Bot, Send, Lightbulb, Target, Brain, Zap } from 'lucide-react';

interface ChatMessage {
  id: number;
  text: string;
  sender: 'user' | 'jarvis';
  timestamp: Date;
  type?: 'analysis' | 'quiz' | 'explanation' | 'motivation';
}

const JarvisChat = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 1,
      text: "Good day, Agent. I am J.A.R.V.I.S., your personal study assistant. How may I assist with your training today?",
      sender: 'jarvis',
      timestamp: new Date(),
      type: 'analysis'
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const jarvisResponses = {
    greeting: [
      "At your service, Agent. What knowledge shall we pursue today?",
      "Ready for another training session? I've analyzed your recent performance.",
      "Your dedication is admirable, Agent. How can I enhance your learning today?"
    ],
    motivation: [
      "As Captain Rogers would say: 'I can do this all day.' And so can you.",
      "Remember, even Tony Stark started with basics. Every genius has a beginning.",
      "Channel your inner Arc Reactor - consistent energy leads to extraordinary results.",
      "The path of a hero requires persistence. You're already showing that spirit."
    ],
    study: [
      "Initiating mission analysis... Let me break this down into manageable components.",
      "Processing your query through the Stark database...",
      "Running enhanced learning protocols... Here's what I've found:",
      "Accessing S.H.I.E.L.D. knowledge archives for optimal explanation..."
    ]
  };

  const quickActions = [
    { label: "Explain Like Groot", icon: Brain, type: "explanation" },
    { label: "Quiz Mode", icon: Target, type: "quiz" },
    { label: "Mission Brief", icon: Lightbulb, type: "analysis" },
    { label: "Pep Talk", icon: Zap, type: "motivation" }
  ];

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: ChatMessage = {
      id: messages.length + 1,
      text: inputValue,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const currentMessage = inputValue;
    setInputValue('');
    setIsTyping(true);

    try {
      const response = await fetch('/api/chat-with-gemini', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          message: currentMessage,
          messageType: 'analysis'
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get response');
      }

      const data = await response.json();
      
      const jarvisMessage: ChatMessage = {
        id: messages.length + 2,
        text: data.response,
        sender: 'jarvis',
        timestamp: new Date(),
        type: 'analysis'
      };

      setMessages(prev => [...prev, jarvisMessage]);
    } catch (error) {
      console.error('Error:', error);
      const errorMessage: ChatMessage = {
        id: messages.length + 2,
        text: "I apologize, Agent. I'm experiencing technical difficulties. Please try again.",
        sender: 'jarvis',
        timestamp: new Date(),
        type: 'analysis'
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleQuickAction = async (type: string) => {
    let prompt = "";
    switch (type) {
      case "explanation":
        prompt = "Explain a complex concept in the simplest way possible, like you're talking to a child or Groot from Guardians of the Galaxy.";
        break;
      case "quiz":
        prompt = "Create an engaging quiz question on a random educational topic that would challenge a student.";
        break;
      case "analysis":
        prompt = "Provide a mission brief style analysis about effective study strategies for today.";
        break;
      case "motivation":
        prompt = "Give an inspiring motivational message to help someone who might be struggling with their studies.";
        break;
    }

    setIsTyping(true);

    try {
      const response = await fetch('/api/chat-with-gemini', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          message: prompt,
          messageType: type
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get response');
      }

      const data = await response.json();
      
      const jarvisMessage: ChatMessage = {
        id: messages.length + 1,
        text: data.response,
        sender: 'jarvis',
        timestamp: new Date(),
        type: type as any
      };

      setMessages(prev => [...prev, jarvisMessage]);
    } catch (error) {
      console.error('Error:', error);
      const errorMessage: ChatMessage = {
        id: messages.length + 1,
        text: "I apologize, Agent. I'm experiencing technical difficulties. Please try again.",
        sender: 'jarvis',
        timestamp: new Date(),
        type: type as any
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const getMessageIcon = (type?: string) => {
    switch (type) {
      case 'analysis': return <Lightbulb className="h-4 w-4" />;
      case 'quiz': return <Target className="h-4 w-4" />;
      case 'explanation': return <Brain className="h-4 w-4" />;
      case 'motivation': return <Zap className="h-4 w-4" />;
      default: return <Bot className="h-4 w-4" />;
    }
  };

  return (
    <Card className="hologram-panel h-[600px] flex flex-col">
      <CardHeader>
        <CardTitle className="font-orbitron flex items-center gap-2 jarvis-text">
          <Bot className="h-5 w-5 arc-reactor" />
          J.A.R.V.I.S. ASSISTANT
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col space-y-4">
        {/* Quick Actions */}
        <div className="flex flex-wrap gap-2">
          {quickActions.map((action) => (
            <Button
              key={action.label}
              variant="outline"
              size="sm"
              onClick={() => handleQuickAction(action.type)}
              className="hero-badge text-xs"
            >
              <action.icon className="h-3 w-3 mr-1" />
              {action.label}
            </Button>
          ))}
        </div>

        {/* Chat Messages */}
        <ScrollArea className="flex-1 pr-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[80%] p-3 rounded-lg ${
                    message.sender === 'user'
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-muted border border-border/50'
                  }`}
                >
                  {message.sender === 'jarvis' && (
                    <div className="flex items-center gap-2 mb-2">
                      {getMessageIcon(message.type)}
                      <Badge variant="outline" className="text-xs">
                        {message.type?.toUpperCase() || 'JARVIS'}
                      </Badge>
                    </div>
                  )}
                  <p className="text-sm">{message.text}</p>
                  <p className="text-xs opacity-70 mt-1">
                    {message.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-muted p-3 rounded-lg border border-border/50">
                  <div className="flex items-center gap-2">
                    <Bot className="h-4 w-4 animate-pulse" />
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="flex gap-2">
          <Input
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Ask Jarvis anything..."
            onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            className="bg-input border-border/50"
          />
          <Button onClick={handleSendMessage} className="arc-reactor">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default JarvisChat;