import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Shield, Zap, Target, Clock, BookOpen, Trophy } from 'lucide-react';

const Dashboard = () => {
  const heroStats = {
    powerLevel: 85,
    streak: 7,
    missionsCompleted: 23,
    todayStudyTime: 4.5
  };

  const dailyMissions = [
    { id: 1, title: "Physics Training Session", time: "09:00", status: "completed", type: "Thor" },
    { id: 2, title: "Mathematics Combat Drill", time: "14:00", status: "active", type: "Iron Man" },
    { id: 3, title: "Chemistry Shield Analysis", time: "16:30", status: "pending", type: "Captain America" },
    { id: 4, title: "Biology Hulk Study", time: "19:00", status: "pending", type: "Hulk" }
  ];

  const infinityStones = [
    { name: "Mathematics", color: "bg-secondary", progress: 78, glow: "glow-iron" },
    { name: "Physics", color: "bg-primary", progress: 85, glow: "glow-arc" },
    { name: "Chemistry", color: "bg-success", progress: 62, glow: "" },
    { name: "Biology", color: "bg-accent", progress: 91, glow: "glow-gold" },
    { name: "History", color: "bg-purple-600", progress: 55, glow: "" },
    { name: "Literature", color: "bg-orange-600", progress: 70, glow: "" }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-4xl font-orbitron font-bold jarvis-text">
          AVENGERS HQ - MISSION CONTROL
        </h1>
        <p className="text-muted-foreground font-exo">
          Welcome back, Agent. Your training progress is being monitored.
        </p>
      </div>

      {/* Hero Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="hologram-panel">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Power Level</CardTitle>
            <Zap className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-orbitron font-bold text-primary">
              {heroStats.powerLevel}%
            </div>
            <Progress value={heroStats.powerLevel} className="mt-2 energy-bar" />
          </CardContent>
        </Card>

        <Card className="hologram-panel">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Hero Streak</CardTitle>
            <Target className="h-4 w-4 text-secondary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-orbitron font-bold text-secondary">
              {heroStats.streak} days
            </div>
            <p className="text-xs text-muted-foreground">
              Keep the momentum, hero!
            </p>
          </CardContent>
        </Card>

        <Card className="hologram-panel">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Missions Complete</CardTitle>
            <Shield className="h-4 w-4 text-success" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-orbitron font-bold text-success">
              {heroStats.missionsCompleted}
            </div>
            <p className="text-xs text-muted-foreground">
              This month
            </p>
          </CardContent>
        </Card>

        <Card className="hologram-panel">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Study Time</CardTitle>
            <Clock className="h-4 w-4 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-orbitron font-bold text-accent">
              {heroStats.todayStudyTime}h
            </div>
            <p className="text-xs text-muted-foreground">
              Today's training
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Daily Mission Log */}
      <Card className="hologram-panel">
        <CardHeader>
          <CardTitle className="font-orbitron flex items-center gap-2">
            <Shield className="h-5 w-5" />
            DAILY MISSION LOG
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {dailyMissions.map((mission) => (
              <div key={mission.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border border-border/50">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${
                    mission.status === 'completed' ? 'bg-success animate-pulse' :
                    mission.status === 'active' ? 'bg-primary animate-pulse' :
                    'bg-muted-foreground'
                  }`} />
                  <div>
                    <p className="font-medium">{mission.title}</p>
                    <p className="text-sm text-muted-foreground">{mission.time} - {mission.type} Protocol</p>
                  </div>
                </div>
                <Badge variant={
                  mission.status === 'completed' ? 'default' :
                  mission.status === 'active' ? 'secondary' :
                  'outline'
                } className="hero-badge">
                  {mission.status.toUpperCase()}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Infinity Stones Progress */}
      <Card className="hologram-panel">
        <CardHeader>
          <CardTitle className="font-orbitron flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            INFINITY KNOWLEDGE STONES
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {infinityStones.map((stone) => (
              <div key={stone.name} className="text-center space-y-2">
                <div className={`w-16 h-16 mx-auto rounded-full ${stone.color} ${stone.glow} flex items-center justify-center animate-float`}>
                  <Trophy className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-medium">{stone.name}</h3>
                <Progress value={stone.progress} className="energy-bar" />
                <p className="text-xs text-muted-foreground">{stone.progress}% mastery</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Motivational Quote */}
      <Card className="hologram-panel text-center">
        <CardContent className="pt-6">
          <blockquote className="text-lg font-orbitron text-primary animate-text-glow">
            "I can do this all day."
          </blockquote>
          <p className="text-sm text-muted-foreground mt-2">— Captain America</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;